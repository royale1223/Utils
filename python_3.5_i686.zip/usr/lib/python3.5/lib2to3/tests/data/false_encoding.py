#!/data/data/com.termux/files/usr/bin/env python
print '#coding=0'
